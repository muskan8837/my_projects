"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ChevronLeft, ChevronRight, Info, Play, RotateCcw, BookOpen, Pause, PlayCircle } from "lucide-react"
import type { JSX } from "react"

interface State {
  id: string
  x: number
  y: number
  isInitial?: boolean
  isFinal?: boolean
}

interface Transition {
  from: string
  to: string
  label: string
  isEpsilon?: boolean
  curveOffset?: number
}

interface AutomatonData {
  states: State[]
  transitions: Transition[]
  alphabet: string[]
}

interface RegexNode {
  type: "concat" | "union" | "star" | "symbol"
  value?: string
  left?: RegexNode
  right?: RegexNode
  x?: number
  y?: number
}

interface ConversionExample {
  id: string
  name: string
  type: "nfa-to-dfa" | "nfa-to-regex" | "dfa-to-regex" | "enfa-to-dfa"
  description: string
  originalAutomaton: AutomatonData
  convertedAutomaton: AutomatonData
  regexResult?: string
  regexTree?: RegexNode
  steps: ConversionStep[]
}

interface ConversionStep {
  id: number
  title: string
  description: string
  explanation: string
  highlightedElements: string[]
  newElements: string[]
  currentAutomaton?: AutomatonData
}

const examples: ConversionExample[] = [
  // NFA to DFA Examples
  {
    id: "nfa-dfa-1",
    name: "NFA to DFA - Ending with 01",
    type: "nfa-to-dfa",
    description: 'Convert NFA accepting strings ending with "01"',
    originalAutomaton: {
      states: [
        { id: "q0", x: 100, y: 150, isInitial: true },
        { id: "q1", x: 280, y: 100 },
        { id: "q2", x: 450, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q0", label: "0,1", curveOffset: -40 },
        { from: "q0", to: "q1", label: "0", curveOffset: 0 },
        { from: "q1", to: "q2", label: "1", curveOffset: 0 },
      ],
      alphabet: ["0", "1"],
    },
    convertedAutomaton: {
      states: [
        { id: "{q0}", x: 80, y: 150, isInitial: true },
        { id: "{q0,q1}", x: 240, y: 100 },
        { id: "{q2}", x: 400, y: 150, isFinal: true },
        { id: "∅", x: 240, y: 200 },
      ],
      transitions: [
        { from: "{q0}", to: "{q0,q1}", label: "0", curveOffset: 0 },
        { from: "{q0}", to: "{q0}", label: "1", curveOffset: -40 },
        { from: "{q0,q1}", to: "{q0,q1}", label: "0", curveOffset: -40 },
        { from: "{q0,q1}", to: "{q2}", label: "1", curveOffset: 0 },
        { from: "{q2}", to: "∅", label: "0,1", curveOffset: 0 },
        { from: "∅", to: "∅", label: "0,1", curveOffset: -40 },
      ],
      alphabet: ["0", "1"],
    },
    steps: [
      {
        id: 1,
        title: "Initialize with start state",
        description: "Create initial DFA state from NFA start state",
        explanation:
          "The DFA construction begins with the ε-closure of the NFA start state. Since there are no ε-transitions, {q0} becomes our initial DFA state.",
        highlightedElements: ["q0"],
        newElements: ["{q0}"],
      },
      {
        id: 2,
        title: "Process transitions from {q0}",
        description: "Find all possible transitions on input symbols",
        explanation:
          "From q0 on input 0: we can go to both q0 and q1. This creates the new DFA state {q0,q1}. On input 1: we stay in q0.",
        highlightedElements: ["q0", "q1"],
        newElements: ["{q0,q1}"],
      },
      {
        id: 3,
        title: "Process transitions from {q0,q1}",
        description: "Handle the compound state transitions",
        explanation:
          "From the set {q0,q1}: On input 0, both q0 and q1 can be reached, so result is {q0,q1}. On input 1, q0 stays and q1 goes to q2, so result is {q2}.",
        highlightedElements: ["q0", "q1", "q2"],
        newElements: ["{q2}"],
      },
      {
        id: 4,
        title: "Complete remaining states",
        description: "Process all remaining unprocessed states",
        explanation:
          "State {q2} has no outgoing transitions in the original NFA, so it goes to ∅ on both inputs. State ∅ transitions to itself on all inputs (dead state).",
        highlightedElements: ["q2"],
        newElements: ["∅"],
      },
    ],
  },
  {
    id: "nfa-dfa-2",
    name: "NFA to DFA - Multiple Paths",
    type: "nfa-to-dfa",
    description: 'Convert NFA with parallel paths for "ab" or "ba"',
    originalAutomaton: {
      states: [
        { id: "q0", x: 100, y: 150, isInitial: true },
        { id: "q1", x: 250, y: 100 },
        { id: "q2", x: 400, y: 100, isFinal: true },
        { id: "q3", x: 250, y: 200 },
        { id: "q4", x: 400, y: 200, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q1", label: "a", curveOffset: 0 },
        { from: "q0", to: "q3", label: "b", curveOffset: 0 },
        { from: "q1", to: "q2", label: "b", curveOffset: 0 },
        { from: "q3", to: "q4", label: "a", curveOffset: 0 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [
        { id: "{q0}", x: 80, y: 150, isInitial: true },
        { id: "{q1}", x: 220, y: 100 },
        { id: "{q3}", x: 220, y: 200 },
        { id: "{q2}", x: 360, y: 100, isFinal: true },
        { id: "{q4}", x: 360, y: 200, isFinal: true },
        { id: "∅", x: 480, y: 150 },
      ],
      transitions: [
        { from: "{q0}", to: "{q1}", label: "a", curveOffset: 0 },
        { from: "{q0}", to: "{q3}", label: "b", curveOffset: 0 },
        { from: "{q1}", to: "{q2}", label: "b", curveOffset: 0 },
        { from: "{q1}", to: "∅", label: "a", curveOffset: 0 },
        { from: "{q3}", to: "{q4}", label: "a", curveOffset: 0 },
        { from: "{q3}", to: "∅", label: "b", curveOffset: 0 },
        { from: "{q2}", to: "∅", label: "a,b", curveOffset: 0 },
        { from: "{q4}", to: "∅", label: "a,b", curveOffset: 0 },
        { from: "∅", to: "∅", label: "a,b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    steps: [
      {
        id: 1,
        title: "Start with initial state",
        description: "Begin DFA construction with {q0}",
        explanation:
          "The conversion starts with the initial state of the NFA, which becomes the first state of our DFA.",
        highlightedElements: ["q0"],
        newElements: ["{q0}"],
      },
      {
        id: 2,
        title: "Process transitions from {q0}",
        description: "Create new states for each transition",
        explanation:
          'From q0: on input "a" we go to q1, creating DFA state {q1}. On input "b" we go to q3, creating DFA state {q3}.',
        highlightedElements: ["q0", "q1", "q3"],
        newElements: ["{q1}", "{q3}"],
      },
      {
        id: 3,
        title: "Complete all transitions",
        description: "Process remaining states and add dead state",
        explanation:
          "From {q1} on 'b' we get {q2}, from {q3} on 'a' we get {q4}. All other transitions lead to the dead state ∅.",
        highlightedElements: ["q1", "q2", "q3", "q4"],
        newElements: ["{q2}", "{q4}", "∅"],
      },
    ],
  },

  // Epsilon NFA to DFA Examples
  {
    id: "enfa-dfa-1",
    name: "ε-NFA to DFA - Basic",
    type: "enfa-to-dfa",
    description: "Convert ε-NFA with epsilon transitions",
    originalAutomaton: {
      states: [
        { id: "q0", x: 80, y: 150, isInitial: true },
        { id: "q1", x: 200, y: 100 },
        { id: "q2", x: 200, y: 200 },
        { id: "q3", x: 350, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q1", label: "ε", isEpsilon: true, curveOffset: 0 },
        { from: "q0", to: "q2", label: "a", curveOffset: 0 },
        { from: "q1", to: "q3", label: "b", curveOffset: 0 },
        { from: "q2", to: "q3", label: "b", curveOffset: 0 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [
        { id: "{q0,q1}", x: 100, y: 150, isInitial: true },
        { id: "{q2}", x: 250, y: 100 },
        { id: "{q3}", x: 400, y: 150, isFinal: true },
        { id: "∅", x: 250, y: 200 },
      ],
      transitions: [
        { from: "{q0,q1}", to: "{q2}", label: "a", curveOffset: 0 },
        { from: "{q0,q1}", to: "{q3}", label: "b", curveOffset: 0 },
        { from: "{q2}", to: "{q3}", label: "b", curveOffset: 0 },
        { from: "{q2}", to: "∅", label: "a", curveOffset: 0 },
        { from: "{q3}", to: "∅", label: "a,b", curveOffset: 0 },
        { from: "∅", to: "∅", label: "a,b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    steps: [
      {
        id: 1,
        title: "Compute ε-closure of start state",
        description: "Find all states reachable via ε-transitions",
        explanation:
          "ε-closure(q0) = {q0, q1} because q0 can reach q1 via an ε-transition. This becomes our initial DFA state.",
        highlightedElements: ["q0", "q1"],
        newElements: ["{q0,q1}"],
      },
      {
        id: 2,
        title: "Process transitions from {q0,q1}",
        description: "Find transitions for the compound state",
        explanation: "From {q0,q1}: on 'a', q0 goes to q2, so we get {q2}. On 'b', q1 goes to q3, so we get {q3}.",
        highlightedElements: ["q0", "q1", "q2", "q3"],
        newElements: ["{q2}", "{q3}"],
      },
      {
        id: 3,
        title: "Complete remaining transitions",
        description: "Process all remaining states",
        explanation: "From {q2} on 'b' we get {q3}, on 'a' we get ∅. From {q3} all transitions go to ∅.",
        highlightedElements: ["q2", "q3"],
        newElements: ["∅"],
      },
    ],
  },
  {
    id: "enfa-dfa-2",
    name: "ε-NFA to DFA - Complex",
    type: "enfa-to-dfa",
    description: "Convert complex ε-NFA with multiple epsilon paths",
    originalAutomaton: {
      states: [
        { id: "q0", x: 80, y: 150, isInitial: true },
        { id: "q1", x: 180, y: 100 },
        { id: "q2", x: 180, y: 200 },
        { id: "q3", x: 280, y: 100 },
        { id: "q4", x: 280, y: 200 },
        { id: "q5", x: 400, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q1", label: "ε", isEpsilon: true, curveOffset: 0 },
        { from: "q0", to: "q2", label: "ε", isEpsilon: true, curveOffset: 0 },
        { from: "q1", to: "q3", label: "a", curveOffset: 0 },
        { from: "q2", to: "q4", label: "b", curveOffset: 0 },
        { from: "q3", to: "q5", label: "ε", isEpsilon: true, curveOffset: 0 },
        { from: "q4", to: "q5", label: "ε", isEpsilon: true, curveOffset: 0 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [
        { id: "{q0,q1,q2}", x: 100, y: 150, isInitial: true },
        { id: "{q3,q5}", x: 280, y: 100, isFinal: true },
        { id: "{q4,q5}", x: 280, y: 200, isFinal: true },
        { id: "∅", x: 400, y: 150 },
      ],
      transitions: [
        { from: "{q0,q1,q2}", to: "{q3,q5}", label: "a", curveOffset: 0 },
        { from: "{q0,q1,q2}", to: "{q4,q5}", label: "b", curveOffset: 0 },
        { from: "{q3,q5}", to: "∅", label: "a,b", curveOffset: 0 },
        { from: "{q4,q5}", to: "∅", label: "a,b", curveOffset: 0 },
        { from: "∅", to: "∅", label: "a,b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    steps: [
      {
        id: 1,
        title: "Compute ε-closure of start state",
        description: "Find all states reachable via ε-transitions from q0",
        explanation: "ε-closure(q0) = {q0, q1, q2} because q0 can reach both q1 and q2 via ε-transitions.",
        highlightedElements: ["q0", "q1", "q2"],
        newElements: ["{q0,q1,q2}"],
      },
      {
        id: 2,
        title: "Process transitions and compute ε-closures",
        description: "Find transitions and their ε-closures",
        explanation:
          "From {q0,q1,q2}: on 'a', q1→q3, then ε-closure(q3)={q3,q5}. On 'b', q2→q4, then ε-closure(q4)={q4,q5}.",
        highlightedElements: ["q1", "q2", "q3", "q4", "q5"],
        newElements: ["{q3,q5}", "{q4,q5}"],
      },
      {
        id: 3,
        title: "Complete the DFA",
        description: "All final states lead to dead state",
        explanation:
          "Both {q3,q5} and {q4,q5} are final states (contain q5). All their transitions lead to the dead state ∅.",
        highlightedElements: ["q3", "q4", "q5"],
        newElements: ["∅"],
      },
    ],
  },

  // NFA to Regular Expression Examples
  {
    id: "nfa-regex-1",
    name: "NFA to RegEx - Simple",
    type: "nfa-to-regex",
    description: "Convert simple NFA to regular expression using state elimination",
    originalAutomaton: {
      states: [
        { id: "q0", x: 100, y: 150, isInitial: true },
        { id: "q1", x: 250, y: 100 },
        { id: "q2", x: 400, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q1", label: "a", curveOffset: 0 },
        { from: "q0", to: "q2", label: "b", curveOffset: 0 },
        { from: "q1", to: "q2", label: "b", curveOffset: 0 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [],
      transitions: [],
      alphabet: ["a", "b"],
    },
    regexResult: "ab + b",
    regexTree: {
      type: "union",
      left: {
        type: "concat",
        left: { type: "symbol", value: "a", x: 150, y: 120 },
        right: { type: "symbol", value: "b", x: 200, y: 120 },
        x: 175,
        y: 100,
      },
      right: { type: "symbol", value: "b", x: 275, y: 120 },
      x: 225,
      y: 80,
    },
    steps: [
      {
        id: 1,
        title: "Add new start and final states",
        description: "Prepare automaton for state elimination method",
        explanation:
          "Add a new start state with ε-transition to original start, and new final state with ε-transitions from all original final states.",
        highlightedElements: ["q0", "q2"],
        newElements: ["qs", "qf"],
      },
      {
        id: 2,
        title: "Eliminate state q1",
        description: "Remove q1 and update transitions",
        explanation:
          "When eliminating q1, we create a direct transition from q0 to q2 with label 'ab' (combining q0→q1 'a' and q1→q2 'b').",
        highlightedElements: ["q1"],
        newElements: [],
      },
      {
        id: 3,
        title: "Final regular expression",
        description: "Complete elimination to get final regex",
        explanation: "After eliminating all intermediate states, we get the regular expression: ab + b",
        highlightedElements: ["q0", "q2"],
        newElements: [],
      },
    ],
  },
  {
    id: "nfa-regex-2",
    name: "NFA to RegEx - With Loop",
    type: "nfa-to-regex",
    description: "Convert NFA with self-loop to regular expression",
    originalAutomaton: {
      states: [
        { id: "q0", x: 100, y: 150, isInitial: true },
        { id: "q1", x: 300, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q0", label: "a", curveOffset: -40 },
        { from: "q0", to: "q1", label: "b", curveOffset: 0 },
        { from: "q1", to: "q1", label: "b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [],
      transitions: [],
      alphabet: ["a", "b"],
    },
    regexResult: "a*bb*",
    regexTree: {
      type: "concat",
      left: {
        type: "star",
        left: { type: "symbol", value: "a", x: 120, y: 120 },
        x: 120,
        y: 100,
      },
      right: {
        type: "concat",
        left: { type: "symbol", value: "b", x: 180, y: 120 },
        right: {
          type: "star",
          left: { type: "symbol", value: "b", x: 240, y: 120 },
          x: 240,
          y: 100,
        },
        x: 210,
        y: 100,
      },
      x: 180,
      y: 80,
    },
    steps: [
      {
        id: 1,
        title: "Identify self-loops",
        description: "Handle self-loops in the automaton",
        explanation:
          "State q0 has a self-loop with 'a', and q1 has a self-loop with 'b'. These become Kleene stars in the regex.",
        highlightedElements: ["q0", "q1"],
        newElements: [],
      },
      {
        id: 2,
        title: "Apply state elimination",
        description: "Eliminate states to build regex",
        explanation:
          "The self-loop on q0 becomes 'a*', the transition q0→q1 is 'b', and the self-loop on q1 becomes 'b*'.",
        highlightedElements: ["q0", "q1"],
        newElements: [],
      },
      {
        id: 3,
        title: "Construct final regex",
        description: "Combine all parts into final expression",
        explanation:
          "Concatenating all parts: a* (from q0 self-loop) + b (transition) + b* (from q1 self-loop) = a*bb*",
        highlightedElements: [],
        newElements: [],
      },
    ],
  },

  // DFA to Regular Expression Examples
  {
    id: "dfa-regex-1",
    name: "DFA to RegEx - Simple",
    type: "dfa-to-regex",
    description: "Convert simple DFA to regular expression using state elimination",
    originalAutomaton: {
      states: [
        { id: "q0", x: 100, y: 150, isInitial: true },
        { id: "q1", x: 300, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q0", label: "b", curveOffset: -40 },
        { from: "q0", to: "q1", label: "a", curveOffset: 0 },
        { from: "q1", to: "q1", label: "a,b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [],
      transitions: [],
      alphabet: ["a", "b"],
    },
    regexResult: "b*a(a+b)*",
    regexTree: {
      type: "concat",
      left: {
        type: "star",
        left: { type: "symbol", value: "b", x: 120, y: 120 },
        x: 120,
        y: 100,
      },
      right: {
        type: "concat",
        left: { type: "symbol", value: "a", x: 180, y: 120 },
        right: {
          type: "star",
          left: {
            type: "union",
            left: { type: "symbol", value: "a", x: 220, y: 140 },
            right: { type: "symbol", value: "b", x: 260, y: 140 },
            x: 240,
            y: 120,
          },
          x: 240,
          y: 100,
        },
        x: 210,
        y: 100,
      },
      x: 180,
      y: 80,
    },
    steps: [
      {
        id: 1,
        title: "Add new start and final states",
        description: "Prepare automaton for state elimination method",
        explanation:
          "Add a new start state with ε-transition to original start, and new final state with ε-transitions from all original final states.",
        highlightedElements: ["q0", "q1"],
        newElements: ["qs", "qf"],
      },
      {
        id: 2,
        title: "Eliminate state q0",
        description: "Remove q0 and update transitions",
        explanation: "When eliminating q0, the self-loop 'b' becomes 'b*', and the transition to q1 becomes 'b*a'.",
        highlightedElements: ["q0"],
        newElements: [],
      },
      {
        id: 3,
        title: "Eliminate state q1",
        description: "Remove q1 and create final expression",
        explanation: "Eliminating q1 with its self-loop '(a+b)' creates the final regular expression: b*a(a+b)*",
        highlightedElements: ["q1"],
        newElements: [],
      },
    ],
  },
  {
    id: "dfa-regex-2",
    name: "DFA to RegEx - Complex",
    type: "dfa-to-regex",
    description: "Convert more complex DFA with multiple states",
    originalAutomaton: {
      states: [
        { id: "q0", x: 80, y: 150, isInitial: true },
        { id: "q1", x: 200, y: 100 },
        { id: "q2", x: 320, y: 150, isFinal: true },
      ],
      transitions: [
        { from: "q0", to: "q1", label: "a", curveOffset: 0 },
        { from: "q0", to: "q0", label: "b", curveOffset: -40 },
        { from: "q1", to: "q2", label: "b", curveOffset: 0 },
        { from: "q1", to: "q0", label: "a", curveOffset: 20 },
        { from: "q2", to: "q2", label: "a,b", curveOffset: -40 },
      ],
      alphabet: ["a", "b"],
    },
    convertedAutomaton: {
      states: [],
      transitions: [],
      alphabet: ["a", "b"],
    },
    regexResult: "(b+aa)*ab(a+b)*",
    regexTree: {
      type: "concat",
      left: {
        type: "star",
        left: {
          type: "union",
          left: { type: "symbol", value: "b", x: 100, y: 140 },
          right: {
            type: "concat",
            left: { type: "symbol", value: "a", x: 130, y: 140 },
            right: { type: "symbol", value: "a", x: 150, y: 140 },
            x: 140,
            y: 140,
          },
          x: 120,
          y: 120,
        },
        x: 120,
        y: 100,
      },
      right: {
        type: "concat",
        left: {
          type: "concat",
          left: { type: "symbol", value: "a", x: 200, y: 140 },
          right: { type: "symbol", value: "b", x: 220, y: 140 },
          x: 210,
          y: 120,
        },
        right: {
          type: "star",
          left: {
            type: "union",
            left: { type: "symbol", value: "a", x: 260, y: 140 },
            right: { type: "symbol", value: "b", x: 280, y: 140 },
            x: 270,
            y: 120,
          },
          x: 270,
          y: 100,
        },
        x: 240,
        y: 100,
      },
      x: 200,
      y: 80,
    },
    steps: [
      {
        id: 1,
        title: "Setup for elimination",
        description: "Add new start and final states",
        explanation:
          "Add new start state qs with ε-transition to q0, and new final state qf with ε-transition from q2.",
        highlightedElements: ["q0", "q2"],
        newElements: ["qs", "qf"],
      },
      {
        id: 2,
        title: "Eliminate q1",
        description: "Remove intermediate state q1",
        explanation: "Eliminating q1 creates new transitions: q0 to q2 with 'ab', and q0 to q0 with 'aa'.",
        highlightedElements: ["q1"],
        newElements: [],
      },
      {
        id: 3,
        title: "Final expression",
        description: "Complete the regular expression",
        explanation: "Final regular expression: (b+aa)*ab(a+b)*",
        highlightedElements: ["q0", "q2"],
        newElements: [],
      },
    ],
  },
]

export default function FormalLanguageConverter() {
  const [selectedExample, setSelectedExample] = useState<ConversionExample>(examples[0])
  const [currentStep, setCurrentStep] = useState(0)
  const [showAllSteps, setShowAllSteps] = useState(false)
  const [isAutoPlaying, setIsAutoPlaying] = useState(false)
  const [autoPlayInterval, setAutoPlayInterval] = useState<NodeJS.Timeout | null>(null)

  const handleExampleChange = (exampleId: string) => {
    const example = examples.find((ex) => ex.id === exampleId)
    if (example) {
      setSelectedExample(example)
      setCurrentStep(0)
      stopAutoPlay()
    }
  }

  const nextStep = () => {
    if (currentStep < selectedExample.steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      stopAutoPlay()
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const resetSteps = () => {
    setCurrentStep(0)
    stopAutoPlay()
  }

  const startAutoPlay = () => {
    if (!isAutoPlaying) {
      setIsAutoPlaying(true)
      const interval = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev < selectedExample.steps.length - 1) {
            return prev + 1
          } else {
            setIsAutoPlaying(false)
            return prev
          }
        })
      }, 2500)
      setAutoPlayInterval(interval)
    }
  }

  const stopAutoPlay = () => {
    setIsAutoPlaying(false)
    if (autoPlayInterval) {
      clearInterval(autoPlayInterval)
      setAutoPlayInterval(null)
    }
  }

  useEffect(() => {
    return () => {
      if (autoPlayInterval) {
        clearInterval(autoPlayInterval)
      }
    }
  }, [autoPlayInterval])

  const getConversionTypeLabel = (type: string) => {
    switch (type) {
      case "nfa-to-dfa":
        return "NFA → DFA"
      case "nfa-to-regex":
        return "NFA → RegEx"
      case "dfa-to-regex":
        return "DFA → RegEx"
      case "enfa-to-dfa":
        return "ε-NFA → DFA"
      default:
        return "Conversion"
    }
  }

  const RegexTreeDiagram = ({ tree, title }: { tree: RegexNode; title: string }) => {
    const renderNode = (node: RegexNode): JSX.Element => {
      const { x = 0, y = 0 } = node

      switch (node.type) {
        case "symbol":
          return (
            <g key={`${x}-${y}`}>
              <circle cx={x} cy={y} r="15" fill="#e3f2fd" stroke="#1976d2" strokeWidth="2" />
              <text x={x} y={y + 4} textAnchor="middle" className="text-sm font-medium fill-blue-800">
                {node.value}
              </text>
            </g>
          )
        case "union":
          return (
            <g key={`${x}-${y}`}>
              <circle cx={x} cy={y} r="15" fill="#fff3e0" stroke="#f57c00" strokeWidth="2" />
              <text x={x} y={y + 4} textAnchor="middle" className="text-sm font-bold fill-orange-800">
                +
              </text>
              {node.left && (
                <line x1={x} y1={y + 15} x2={node.left.x} y2={(node.left.y || 0) - 15} stroke="#666" strokeWidth="1" />
              )}
              {node.right && (
                <line
                  x1={x}
                  y1={y + 15}
                  x2={node.right.x}
                  y2={(node.right.y || 0) - 15}
                  stroke="#666"
                  strokeWidth="1"
                />
              )}
              {node.left && renderNode(node.left)}
              {node.right && renderNode(node.right)}
            </g>
          )
        case "concat":
          return (
            <g key={`${x}-${y}`}>
              <circle cx={x} cy={y} r="15" fill="#f3e5f5" stroke="#7b1fa2" strokeWidth="2" />
              <text x={x} y={y + 4} textAnchor="middle" className="text-sm font-bold fill-purple-800">
                ·
              </text>
              {node.left && (
                <line x1={x} y1={y + 15} x2={node.left.x} y2={(node.left.y || 0) - 15} stroke="#666" strokeWidth="1" />
              )}
              {node.right && (
                <line
                  x1={x}
                  y1={y + 15}
                  x2={node.right.x}
                  y2={(node.right.y || 0) - 15}
                  stroke="#666"
                  strokeWidth="1"
                />
              )}
              {node.left && renderNode(node.left)}
              {node.right && renderNode(node.right)}
            </g>
          )
        case "star":
          return (
            <g key={`${x}-${y}`}>
              <circle cx={x} cy={y} r="15" fill="#e8f5e8" stroke="#388e3c" strokeWidth="2" />
              <text x={x} y={y + 4} textAnchor="middle" className="text-sm font-bold fill-green-800">
                *
              </text>
              {node.left && (
                <line x1={x} y1={y + 15} x2={node.left.x} y2={(node.left.y || 0) - 15} stroke="#666" strokeWidth="1" />
              )}
              {node.left && renderNode(node.left)}
            </g>
          )
        default:
          return <g></g>
      }
    }

    return (
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 h-80 bg-gray-50">
        <div className="text-sm text-gray-500 mb-2 text-center">{title}</div>
        <div className="text-center mb-4">
          <div className="text-2xl font-mono font-bold text-blue-600 mb-2">{selectedExample.regexResult}</div>
          <div className="text-sm text-gray-600">Regular Expression</div>
        </div>
        <svg width="100%" height="200" viewBox="0 0 400 200">
          {renderNode(tree)}
        </svg>
      </div>
    )
  }

  const AutomatonDiagram = ({
    automaton,
    title,
    highlightedStates = [],
    newStates = [],
    isRegexResult = false,
  }: {
    automaton: AutomatonData
    title: string
    highlightedStates?: string[]
    newStates?: string[]
    isRegexResult?: boolean
  }) => {
    if (isRegexResult && selectedExample.regexTree) {
      return <RegexTreeDiagram tree={selectedExample.regexTree} title={title} />
    }

    if (isRegexResult || automaton.states.length === 0) {
      return (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 h-80 flex flex-col items-center justify-center bg-gray-50">
          <div className="text-sm text-gray-500 mb-4">{title}</div>
          <div className="text-center">
            <div className="text-2xl font-mono font-bold text-blue-600 mb-4">
              {selectedExample.regexResult || "Regular Expression"}
            </div>
            <div className="text-sm text-gray-600">Final regular expression representing the language</div>
          </div>
        </div>
      )
    }

    return (
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 h-80 bg-gray-50">
        <div className="text-sm text-gray-500 mb-2 text-center">{title}</div>
        <svg width="100%" height="280" viewBox="0 0 550 280">
          {/* Render transitions first (so they appear behind states) */}
          {automaton.transitions.map((transition, index) => {
            const fromState = automaton.states.find((s) => s.id === transition.from)
            const toState = automaton.states.find((s) => s.id === transition.to)

            if (!fromState || !toState) return null

            const isSelfLoop = fromState.id === toState.id
            const isHighlighted =
              highlightedStates.includes(transition.from) || highlightedStates.includes(transition.to)

            if (isSelfLoop) {
              // Create a proper oval self-loop like in textbook diagrams
              const loopRadius = 35
              const loopOffset = 45

              // Position the loop above the state by default, but can be adjusted
              const loopCenterX = fromState.x
              const loopCenterY = fromState.y - loopOffset

              // Create an elliptical path that starts and ends at the state circle
              const startAngle = Math.PI / 6 // 30 degrees
              const endAngle = Math.PI - Math.PI / 6 // 150 degrees

              // Calculate connection points on the state circle
              const connectionRadius = 25
              const startConnectionX = fromState.x + connectionRadius * Math.cos(-startAngle)
              const startConnectionY = fromState.y + connectionRadius * Math.sin(-startAngle)
              const endConnectionX = fromState.x + connectionRadius * Math.cos(-endAngle)
              const endConnectionY = fromState.y + connectionRadius * Math.sin(-endAngle)

              // Calculate the ellipse control points for a smooth oval
              const ellipseWidth = loopRadius * 1.2
              const ellipseHeight = loopRadius * 0.8

              return (
                <g key={index}>
                  {/* Create smooth elliptical self-loop */}
                  <path
                    d={`M ${startConnectionX} ${startConnectionY} 
                        C ${startConnectionX - 20} ${loopCenterY - ellipseHeight} 
                          ${endConnectionX + 20} ${loopCenterY - ellipseHeight} 
                          ${endConnectionX} ${endConnectionY}`}
                    fill="none"
                    stroke={isHighlighted ? "#ef4444" : "#374151"}
                    strokeWidth={isHighlighted ? "3" : "2"}
                    markerEnd="url(#arrowhead)"
                  />

                  {/* Label positioned at the top of the loop */}
                  <text
                    x={loopCenterX}
                    y={loopCenterY - ellipseHeight - 5}
                    textAnchor="middle"
                    className="text-sm fill-gray-700 font-medium"
                    fontSize="12"
                  >
                    {transition.label}
                  </text>
                </g>
              )
            } else {
              // Regular transition with curve support
              const dx = toState.x - fromState.x
              const dy = toState.y - fromState.y
              const distance = Math.sqrt(dx * dx + dy * dy)
              const unitX = dx / distance
              const unitY = dy / distance

              const startX = fromState.x + unitX * 25
              const startY = fromState.y + unitY * 25
              const endX = toState.x - unitX * 25
              const endY = toState.y - unitY * 25

              const midX = (startX + endX) / 2
              const midY = (startY + endY) / 2

              // Apply curve offset for better arrow separation
              const curveOffset = transition.curveOffset || 0
              const perpX = -unitY * curveOffset
              const perpY = unitX * curveOffset
              const controlX = midX + perpX
              const controlY = midY + perpY

              return (
                <g key={index}>
                  <path
                    d={`M ${startX} ${startY} Q ${controlX} ${controlY} ${endX} ${endY}`}
                    fill="none"
                    stroke={isHighlighted ? "#ef4444" : "#374151"}
                    strokeWidth={isHighlighted ? "3" : "2"}
                    markerEnd="url(#arrowhead)"
                  />
                  <text
                    x={controlX}
                    y={controlY - 8}
                    textAnchor="middle"
                    className="text-sm fill-gray-700 font-medium"
                    fontSize="12"
                  >
                    {transition.label}
                  </text>
                </g>
              )
            }
          })}

          {/* Render states */}
          {automaton.states.map((state) => {
            const isHighlighted = highlightedStates.includes(state.id)
            const isNew = newStates.includes(state.id)
            const fillColor = isNew ? "#dcfce7" : isHighlighted ? "#fef2f2" : "#ffffff"
            const strokeColor = isNew ? "#16a34a" : isHighlighted ? "#ef4444" : "#374151"

            return (
              <g key={state.id}>
                {/* Initial state arrow */}
                {state.isInitial && (
                  <line
                    x1={state.x - 50}
                    y1={state.y}
                    x2={state.x - 25}
                    y2={state.y}
                    stroke="#374151"
                    strokeWidth="3"
                    markerEnd="url(#arrowhead)"
                  />
                )}

                {/* State circle */}
                <circle
                  cx={state.x}
                  cy={state.y}
                  r="25"
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth={isHighlighted || isNew ? "3" : "2"}
                />

                {/* Final state double circle */}
                {state.isFinal && (
                  <circle
                    cx={state.x}
                    cy={state.y}
                    r="18"
                    fill="none"
                    stroke={strokeColor}
                    strokeWidth={isHighlighted || isNew ? "2" : "1"}
                  />
                )}

                {/* State label */}
                <text
                  x={state.x}
                  y={state.y + 5}
                  textAnchor="middle"
                  className="text-sm font-bold fill-gray-800"
                  fontSize="14"
                >
                  {state.id}
                </text>
              </g>
            )
          })}

          {/* Arrow marker definition */}
          <defs>
            <marker id="arrowhead" markerWidth="12" markerHeight="8" refX="11" refY="4" orient="auto">
              <polygon points="0 0, 12 4, 0 8" fill="#374151" />
            </marker>
          </defs>
        </svg>
      </div>
    )
  }

  const getCurrentHighlights = () => {
    if (currentStep < selectedExample.steps.length) {
      return {
        highlighted: selectedExample.steps[currentStep].highlightedElements,
        new: selectedExample.steps[currentStep].newElements,
      }
    }
    return { highlighted: [], new: [] }
  }

  const { highlighted, new: newElements } = getCurrentHighlights()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Formal Language Converter</h1>
          </div>
          <p className="text-gray-600 mb-4">
            Interactive tool for visualizing conversions between formal language representations
          </p>

          {/* Example Selection */}
          <div className="flex items-center gap-4">
            <Label htmlFor="example-select" className="text-sm font-medium">
              Select Example:
            </Label>
            <Select value={selectedExample.id} onValueChange={handleExampleChange}>
              <SelectTrigger className="w-96">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <div className="p-2 text-xs font-semibold text-gray-500 border-b">NFA → DFA</div>
                {examples
                  .filter((ex) => ex.type === "nfa-to-dfa")
                  .map((example) => (
                    <SelectItem key={example.id} value={example.id}>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs bg-blue-50">
                          {getConversionTypeLabel(example.type)}
                        </Badge>
                        {example.name}
                      </div>
                    </SelectItem>
                  ))}
                <div className="p-2 text-xs font-semibold text-gray-500 border-b">ε-NFA → DFA</div>
                {examples
                  .filter((ex) => ex.type === "enfa-to-dfa")
                  .map((example) => (
                    <SelectItem key={example.id} value={example.id}>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs bg-green-50">
                          {getConversionTypeLabel(example.type)}
                        </Badge>
                        {example.name}
                      </div>
                    </SelectItem>
                  ))}
                <div className="p-2 text-xs font-semibold text-gray-500 border-b">NFA → RegEx</div>
                {examples
                  .filter((ex) => ex.type === "nfa-to-regex")
                  .map((example) => (
                    <SelectItem key={example.id} value={example.id}>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs bg-purple-50">
                          {getConversionTypeLabel(example.type)}
                        </Badge>
                        {example.name}
                      </div>
                    </SelectItem>
                  ))}
                <div className="p-2 text-xs font-semibold text-gray-500 border-b">DFA → RegEx</div>
                {examples
                  .filter((ex) => ex.type === "dfa-to-regex")
                  .map((example) => (
                    <SelectItem key={example.id} value={example.id}>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs bg-orange-50">
                          {getConversionTypeLabel(example.type)}
                        </Badge>
                        {example.name}
                      </div>
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Original Formalism Panel */}
          <Card className="shadow-lg">
            <CardHeader className="bg-red-50 border-b">
              <CardTitle className="flex items-center gap-2 text-red-800">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                Original ({selectedExample.type.split("-")[0].toUpperCase()})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <AutomatonDiagram
                automaton={selectedExample.originalAutomaton}
                title="Original Automaton"
                highlightedStates={highlighted.filter((h) =>
                  selectedExample.originalAutomaton.states.some((s) => s.id === h),
                )}
              />
              <div className="mt-4 p-3 bg-red-50 rounded-lg">
                <h4 className="font-semibold text-sm text-red-800 mb-2">Structure Summary</h4>
                <div className="text-xs text-red-700 space-y-1">
                  <div>
                    <strong>States:</strong> {selectedExample.originalAutomaton.states.map((s) => s.id).join(", ")}
                  </div>
                  <div>
                    <strong>Final States:</strong>{" "}
                    {selectedExample.originalAutomaton.states
                      .filter((s) => s.isFinal)
                      .map((s) => s.id)
                      .join(", ")}
                  </div>
                  <div>
                    <strong>Alphabet:</strong> {selectedExample.originalAutomaton.alphabet.join(", ")}
                  </div>
                  <div>
                    <strong>Description:</strong> {selectedExample.description}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Converted Formalism Panel */}
          <Card className="shadow-lg">
            <CardHeader className="bg-green-50 border-b">
              <CardTitle className="flex items-center gap-2 text-green-800">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                Converted ({selectedExample.type.split("-to-")[1].toUpperCase()})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <AutomatonDiagram
                automaton={selectedExample.convertedAutomaton}
                title="Converted Result"
                highlightedStates={highlighted.filter((h) =>
                  selectedExample.convertedAutomaton.states.some((s) => s.id === h),
                )}
                newStates={newElements.filter((n) => selectedExample.convertedAutomaton.states.some((s) => s.id === n))}
                isRegexResult={selectedExample.type.includes("regex")}
              />
              <div className="mt-4 p-3 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-sm text-green-800 mb-2">Structure Summary</h4>
                <div className="text-xs text-green-700 space-y-1">
                  {selectedExample.type.includes("regex") ? (
                    <>
                      <div>
                        <strong>Result:</strong> {selectedExample.regexResult}
                      </div>
                      <div>
                        <strong>Type:</strong> Regular Expression
                      </div>
                      <div>
                        <strong>Language:</strong> Same as original automaton
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <strong>States:</strong> {selectedExample.convertedAutomaton.states.map((s) => s.id).join(", ")}
                      </div>
                      <div>
                        <strong>Final States:</strong>{" "}
                        {selectedExample.convertedAutomaton.states
                          .filter((s) => s.isFinal)
                          .map((s) => s.id)
                          .join(", ")}
                      </div>
                    </>
                  )}
                  <div>
                    <strong>Conversion:</strong> {getConversionTypeLabel(selectedExample.type)}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Step-by-Step Conversion */}
        <Card className="shadow-lg">
          <CardHeader className="bg-blue-50 border-b">
            <CardTitle className="flex items-center justify-between">
              <span className="text-blue-800">Step-by-Step Conversion</span>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch id="show-all-steps" checked={showAllSteps} onCheckedChange={setShowAllSteps} />
                  <Label htmlFor="show-all-steps" className="text-sm">
                    Show All Steps
                  </Label>
                </div>
                <Badge variant="outline" className="text-xs">
                  Step {currentStep + 1} of {selectedExample.steps.length}
                </Badge>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {!showAllSteps ? (
              /* Single Step View */
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <Button variant="outline" size="sm" onClick={prevStep} disabled={currentStep === 0}>
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={nextStep}
                      disabled={currentStep === selectedExample.steps.length - 1}
                    >
                      Next
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={resetSteps}>
                      <RotateCcw className="h-4 w-4 mr-1" />
                      Reset
                    </Button>
                    <Button
                      variant={isAutoPlaying ? "destructive" : "default"}
                      size="sm"
                      onClick={isAutoPlaying ? stopAutoPlay : startAutoPlay}
                      disabled={currentStep === selectedExample.steps.length - 1}
                    >
                      {isAutoPlaying ? (
                        <>
                          <Pause className="h-4 w-4 mr-1" />
                          Stop Auto
                        </>
                      ) : (
                        <>
                          <PlayCircle className="h-4 w-4 mr-1" />
                          Auto Play
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {selectedExample.steps[currentStep] && (
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {selectedExample.steps[currentStep].title}
                        </h3>
                        <p className="text-gray-700 mb-3">{selectedExample.steps[currentStep].description}</p>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="ml-4 bg-transparent">
                            <Info className="h-4 w-4 mr-1" />
                            Explain This
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>{selectedExample.steps[currentStep].title}</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <p className="text-gray-700">{selectedExample.steps[currentStep].explanation}</p>
                            <div className="bg-blue-50 p-4 rounded-lg">
                              <h4 className="font-semibold text-blue-800 mb-2">Key Concepts:</h4>
                              <ul className="text-sm text-blue-700 space-y-1">
                                {selectedExample.type === "nfa-to-dfa" && (
                                  <>
                                    <li>• Subset construction algorithm</li>
                                    <li>• State reachability analysis</li>
                                    <li>• Deterministic transition function</li>
                                  </>
                                )}
                                {selectedExample.type === "enfa-to-dfa" && (
                                  <>
                                    <li>• ε-closure computation</li>
                                    <li>• Epsilon transition elimination</li>
                                    <li>• State set construction</li>
                                  </>
                                )}
                                {selectedExample.type.includes("regex") && (
                                  <>
                                    <li>• State elimination method</li>
                                    <li>• Regular expression construction</li>
                                    <li>• Transition label combination</li>
                                  </>
                                )}
                              </ul>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>

                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <Play className="h-5 w-5 text-yellow-600" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm text-yellow-800">
                            <strong>Highlighted Elements:</strong>{" "}
                            {selectedExample.steps[currentStep].highlightedElements.join(", ") || "None"}
                          </p>
                          {selectedExample.steps[currentStep].newElements.length > 0 && (
                            <p className="text-sm text-yellow-800 mt-1">
                              <strong>New Elements:</strong> {selectedExample.steps[currentStep].newElements.join(", ")}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              /* All Steps View */
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {selectedExample.steps.map((step, index) => (
                    <div
                      key={step.id}
                      className={`border rounded-lg p-4 ${index === currentStep ? "border-blue-500 bg-blue-50" : ""}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={index === currentStep ? "default" : "secondary"} className="text-xs">
                            Step {step.id}
                          </Badge>
                          <h4 className="font-semibold">{step.title}</h4>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Info className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>{step.title}</DialogTitle>
                            </DialogHeader>
                            <p className="text-gray-700">{step.explanation}</p>
                          </DialogContent>
                        </Dialog>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{step.description}</p>
                      <div className="text-xs text-gray-500">
                        <span className="font-medium">Highlights:</span> {step.highlightedElements.join(", ") || "None"}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
